﻿using BLL.DTOModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.ServiceInterfaces
{
    public interface IProductService
    {
        Task<IEnumerable<ProductResponseDTO>> GetProducts(
            string nameFilter = null,
            string groupNameFilter = null,
            int? groupIdFilter = null,
            bool includeInactive = false,
            string sortBy = "Name",
            bool ascending = true); 
        Task<ProductResponseDTO> AddProduct(ProductRequestDTO productRequest);

        Task DeactivateProduct(int productId);

        Task ActivateProduct(int productId);

        Task DeleteProduct(int productId);

        Task AddToBasket(int userId, int productId, int quantity);

        Task UpdateBasketItemQuantity(int userId, int productId, int newQuantity);

        Task RemoveFromBasket(int userId, int productId);
    }
}
