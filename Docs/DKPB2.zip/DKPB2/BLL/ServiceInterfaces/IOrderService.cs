﻿using BLL.DTOModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.ServiceInterfaces
{
    internal interface IOrderService
    {
        Task<IEnumerable<OrderResponseDTO>> GetOrders(
       int? orderId = null,
       bool? isPaid = null,
       string sortBy = "Date",
       bool ascending = true);

        Task<OrderResponseDTO> GenerateOrderFromBasket(int userId);

        Task PayOrder(int orderId, decimal amountPaid);
        Task<IEnumerable<OrderPositionResponseDTO>> GetOrderPositions(int orderId);
    }
}
