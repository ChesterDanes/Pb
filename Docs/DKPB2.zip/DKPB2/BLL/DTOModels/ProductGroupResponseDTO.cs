﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.DTOModels
{
    public class ProductGroupResponseDTO
    {
        public int Id { get; }
        public string Name { get; }
        public int? ParentId { get; }

        public ProductGroupResponseDTO(int id, string name, int? parentId)
        {
            Id = id;
            Name = name;
            ParentId = parentId;
        }
    }
}
