﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.DTOModels
{
    public class UserResponseDTO
    {
        public int Id { get; }
        public string Login { get; }
        public Type Type { get; }
        public bool IsActive { get; }
        public int? GroupId { get; }

        public UserResponseDTO(int id, string login, Type type, bool isActive, int? groupId)
        {
            Id = id;
            Login = login;
            Type = type;
            IsActive = isActive;
            GroupId = groupId;
        }
    }
}
