﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.DTOModels
{
    internal class OrderResponseDTO
    {
        public int Id { get;}
        public int UserId { get;}
        public DateTime Date { get;}

        public OrderResponseDTO(int userId, DateTime date)
        {
            UserId = userId;
            Date = date;
        }
    }
}
